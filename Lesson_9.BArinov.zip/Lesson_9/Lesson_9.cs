﻿
Console.WriteLine("Hello, World!\n");


// Task 1
/* 
System.Console.WriteLine("Введите число N: ");
int N = Convert.ToInt32(Console.ReadLine());

string Recursiya(int start, int end)
{
    if (start == end) return start.ToString();
    if (start > end)
    {
        return (start + " "+ Recursiya(start - 1, end));
    }
 return (start + " "+ Recursiya(start + 1, end));

}

System.Console.WriteLine(Recursiya(N, 1));

 */
 
 // Task 2


System.Console.Write("Введите m: ");
int m = int.Parse(Console.ReadLine());
System.Console.Write("Введите n: ");
int n = int.Parse(Console.ReadLine());

int SumNumbers(int numStart, int numEnd) 
{
    if (numStart == numEnd)
    {
        return numStart;
    }
    else
    {
        return numStart + SumNumbers(numStart + 1, numEnd);
    }
}

int sum = SumNumbers(m, n);
Console.WriteLine($"Сумма чисел от {m} до {n} равна {sum}");






